n = int(input())
arr = map(int, input().split())
print(sorted(set(arr))[-2])
